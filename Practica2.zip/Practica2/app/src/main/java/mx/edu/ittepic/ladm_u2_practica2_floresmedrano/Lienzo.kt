package mx.edu.ittepic.ladm_u2_practica2_floresmedrano

import android.graphics.*
import android.view.View


class Lienzo(p:MainActivity): View(p) {
    var burbujaC1=Burbuja(20,0,30)
    var burbujaC2=Burbuja(500,90,30)
    var burbujaC3=Burbuja(150,850,30)
    var burbujaC4=Burbuja(240,150,30)
    var burbujaC5=Burbuja(800,700,30)
    var burbujaG1=Burbuja(400,1000,50)
    var burbujaG2=Burbuja(500,0,50)
    var burbujaG3=Burbuja(50,100,50)
    var burbujaG4=Burbuja(600,600,50)
    var burbujaG5=Burbuja(700,200,50)
    //30 y 50
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var paint = Paint()
        canvas.drawColor(Color.BLACK)
        paint.color = Color.rgb(153, 204, 255)
        burbujaC1.pintar(canvas,paint)
        burbujaC2.pintar(canvas,paint)
        burbujaC3.pintar(canvas,paint)
        burbujaC4.pintar(canvas,paint)
        burbujaC5.pintar(canvas,paint)
        burbujaG1.pintar(canvas,paint)
        burbujaG2.pintar(canvas,paint)
        burbujaG3.pintar(canvas,paint)
        burbujaG4.pintar(canvas,paint)
        burbujaG5.pintar(canvas,paint)
    }

    fun animarCirculo() {
        burbujaC1.rebote(width,height)
        burbujaC2.rebote(width,height)
        burbujaC3.rebote(width,height)
        burbujaC4.rebote(width,height)
        burbujaC5.rebote(width,height)
        burbujaG1.rebote(width,height)
        burbujaG2.rebote(width,height)
        burbujaG3.rebote(width,height)
        burbujaG4.rebote(width,height)
        burbujaG5.rebote(width,height)
        invalidate()
    }
}