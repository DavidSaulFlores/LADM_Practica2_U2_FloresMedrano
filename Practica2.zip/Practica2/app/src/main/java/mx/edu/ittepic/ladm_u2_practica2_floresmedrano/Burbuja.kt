package mx.edu.ittepic.ladm_u2_practica2_floresmedrano

import android.graphics.Canvas
import android.graphics.Paint

class Burbuja () {
    var x = 0f
    var y = 0f
    var radio = 0f
    var incX = 5
    var incY = 5

    constructor(x: Int, y: Int, radio: Int) : this() {
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.radio = radio.toFloat()
        if(this.radio==30F)incY=5
        if(this.radio==50F)incY=15
    }
    fun pintar(c: Canvas, p: Paint){
        c.drawCircle(x,y,radio,p)
    }
    fun rebote(ancho:Int, alto:Int){
        x+= incX
        if(x<=-100 || x>=ancho){
            incX *= -1
        }
        y+= incY
        if(y<=-100 || y>=alto){
            incY *= -1
        }

    }



}