import mx.edu.ittepic.ladm_u2_practica2_floresmedrano.MainActivity

class HiloAnimacion (p:MainActivity):Thread(){
    var puntero = p

    override fun run() {
        super.run()
        sleep(1000)
        while(true){
            sleep(20)
            puntero.runOnUiThread {
                puntero.lienzo!!.animarCirculo()
            }
        }
    }
}